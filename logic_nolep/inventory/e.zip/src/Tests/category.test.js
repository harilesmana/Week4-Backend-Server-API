const request = require('supertest');
const app = require('../app');
const prisma = require('../config/db');

let token;

beforeAll(async () => {
    await prisma.user.deleteMany();
    await prisma.category.deleteMany();

    const res = await request(app)
        .post('/api/auth/register')
        .send({
            name: 'Admin User',
            email: 'admin@example.com',
            password: 'admin123',
            role: 'Admin',
        });

    token = res.body.token;
});

afterAll(async () => {
    await prisma.$disconnect();
});

describe('Category Endpoints', () => {
    it('should create a new category', async () => {
        const res = await request(app)
            .post('/api/categories')
            .set('Authorization', `Bearer ${token}`)
            .send({
                name: 'Test Category',
            });
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('id');
    });

    it('should get all categories', async () => {
        const res = await request(app)
            .get('/api/categories')
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toBeInstanceOf(Array);
    });

    it('should get a single category by ID', async () => {
        const categoriesRes = await request(app)
            .get('/api/categories')
            .set('Authorization', `Bearer ${token}`);
        const categoryId = categoriesRes.body[0].id;

        const res = await request(app)
            .get(`/api/categories/${categoryId}`)
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('id');
    });

    it('should update a category', async () => {
        const categoriesRes = await request(app)
            .get('/api/categories')
            .set('Authorization', `Bearer ${token}`);
        const categoryId = categoriesRes.body[0].id;

        const res = await request(app)
            .put(`/api/categories/${categoryId}`)
            .set('Authorization', `Bearer ${token}`)
            .send({
                name: 'Updated Category',
            });
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('name', 'Updated Category');
    });

    it('should delete a category', async () => {
        const categoriesRes = await request(app)
            .get('/api/categories')
            .set('Authorization', `Bearer ${token}`);
        const categoryId = categoriesRes.body[0].id;

        const res = await request(app)
            .delete(`/api/categories/${categoryId}`)
