const request = require('supertest');
const app = require('../app');
const prisma = require('../config/db');

let token;
let productId;

beforeAll(async () => {
    await prisma.user.deleteMany();
    await prisma.category.deleteMany();
    await prisma.product.deleteMany();
    await prisma.order.deleteMany();
    await prisma.orderItem.deleteMany();

    const res = await request(app)
        .post('/api/auth/register')
        .send({
            name: 'Admin User',
            email: 'admin@example.com',
            password: 'admin123',
            role: 'Admin',
        });

    token = res.body.token;

    const categoryRes = await request(app)
        .post('/api/categories')
        .set('Authorization', `Bearer ${token}`)
        .send({
            name: 'Test Category',
        });

    const productRes = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${token}`)
        .send({
            name: 'Test Product',
            description: 'This is a test product',
            price: 100,
            stock: 10,
            categoryId: categoryRes.body.id,
        });

    productId = productRes.body.id;
});

afterAll(async () => {
    await prisma.$disconnect();
});

describe('Order Endpoints', () => {
    it('should create a new order', async () => {
        const res = await request(app)
            .post('/api/orders')
            .set('Authorization', `Bearer ${token}`)
            .send({
                total: 100,
                userId: 1,
                orderItems: [
                    {
                        quantity: 1,
                        price: 100,
                        productId: productId,
                    },
                ],
            });
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('id');
    });

    it('should get all orders', async () => {
        const res = await request(app)
            .get('/api/orders')
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toBeInstanceOf(Array);
    });

    it('should get a single order by ID', async () => {
        const ordersRes = await request(app)
            .get('/api/orders')
            .set('Authorization', `Bearer ${token}`);
        const orderId = ordersRes.body[0].id;

        const res = await request(app)
            .get(`/api/orders/${orderId}`)
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('id');
    });

    it('should update an order', async () => {
        const ordersRes = await request(app)
            .get('/api/orders')
            .set('Authorization', `Bearer ${token}`);
        const orderId = ordersRes.body[0].id;

        const res = await request(app)
            .put(`/api/orders/${orderId}`)
            .set('Authorization', `Bearer ${token}`)
            .send({
                total: 150,
                userId: 1,
            });
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('total', 150);
    });

    it('should delete an order', async () => {
        const ordersRes = await request(app)
            .get('/api/orders')
            .set('Authorization', `Bearer ${token}`);
        const orderId = ordersRes.body[0].id;

        const res = await request(app)
            .delete(`/api/orders/${orderId}`)
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('message', 'Order deleted successfully');
    });
});
