const request = require('supertest');
const app = require('../app');
const prisma = require('../config/db');

let token;
let userId;
let productId;
let orderId;

beforeAll(async () => {
    await prisma.user.deleteMany();
    await prisma.category.deleteMany();
    await prisma.product.deleteMany();
    await prisma.order.deleteMany();
    await prisma.orderItem.deleteMany();

    
    const userRes = await request(app)
        .post('/api/auth/register')
        .send({
            name: 'Admin User',
            email: 'admin@example.com',
            password: 'admin123',
            role: 'Admin',
        });

    token = userRes.body.token;
    userId = userRes.body.user.id;

    const categoryRes = await request(app)
        .post('/api/categories')
        .set('Authorization', `Bearer ${token}`)
        .send({
            name: 'Test Category',
        });

    const categoryId = categoryRes.body.id;

    const productRes = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${token}`)
        .send({
            name: 'Test Product',
            description: 'This is a test product',
            price: 100,
            stock: 10,
            categoryId: categoryId,
        });

    productId = productRes.body.id;

    const orderRes = await request(app)
        .post('/api/orders')
        .set('Authorization', `Bearer ${token}`)
        .send({
            total: 100,
            userId: userId,
            orderItems: [{
                quantity: 1,
                price: 100,
                productId: productId,
            }],
        });

    orderId = orderRes.body.id;
});

afterAll(async () => {
    await prisma.$disconnect();
});

describe('Order Item Endpoints', () => {
    it('should create a new order item', async () => {
        const res = await request(app)
            .post('/api/order-items')
            .set('Authorization', `Bearer ${token}`)
            .send({
                quantity: 1,
                price: 100,
                productId: productId,
                orderId: orderId,
            });
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('id');
    });

    it('should get all order items', async () => {
        const res = await request(app)
            .get('/api/order-items')
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toBeInstanceOf(Array);
    });

    it('should get a single order item by ID', async () => {
        const orderItemsRes = await request(app)
            .get('/api/order-items')
            .set('Authorization', `Bearer ${token}`);
        const orderItemId = orderItemsRes.body[0].id;

        const res = await request(app)
            .get(`/api/order-items/${orderItemId}`)
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('id');
    });

    it('should update an order item', async () => {
        const orderItemsRes = await request(app)
            .get('/api/order-items')
            .set('Authorization', `Bearer ${token}`);
        const orderItemId = orderItemsRes.body[0].id;

        const res = await request(app)
            .put(`/api/order-items/${orderItemId}`)
            .set('Authorization', `Bearer ${token}`)
            .send({
                quantity: 2,
            });
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('quantity', 2);
    });

    it('should delete an order item', async () => {
        const orderItemsRes = await request(app)
            .get('/api/order-items')
            .set('Authorization', `Bearer ${token}`);
        const orderItemId = orderItemsRes.body[0].id;

        const res = await request(app)
            .delete(`/api/order-items/${orderItemId}`)
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('message', 'Order item deleted successfully');
    });
});
