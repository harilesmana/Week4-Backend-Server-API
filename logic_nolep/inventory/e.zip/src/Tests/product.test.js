const request = require('supertest');
const app = require('../app');
const prisma = require('../config/db');

let token;
let categoryId;

beforeAll(async () => {
    await prisma.user.deleteMany();
    await prisma.category.deleteMany();
    await prisma.product.deleteMany();

    const res = await request(app)
        .post('/api/auth/register')
        .send({
            name: 'Admin User',
            email: 'admin@example.com',
            password: 'admin123',
            role: 'Admin',
        });

    token = res.body.token;

    const categoryRes = await request(app)
        .post('/api/categories')
        .set('Authorization', `Bearer ${token}`)
        .send({
            name: 'Test Category',
        });

    categoryId = categoryRes.body.id;
});

afterAll(async () => {
    await prisma.$disconnect();
});

describe('Product Endpoints', () => {
    it('should create a new product', async () => {
        const res = await request(app)
            .post('/api/products')
            .set('Authorization', `Bearer ${token}`)
            .send({
                name: 'Test Product',
                description: 'This is a test product',
                price: 100,
                stock: 10,
                categoryId: categoryId,
            });
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('id');
    });

    it('should get all products', async () => {
        const res = await request(app)
            .get('/api/products')
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toBeInstanceOf(Array);
    });

    it('should get a single product by ID', async () => {
        const productsRes = await request(app)
            .get('/api/products')
            .set('Authorization', `Bearer ${token}`);
        const productId = productsRes.body[0].id;

        const res = await request(app)
            .get(`/api/products/${productId}`)
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('id');
    });

    it('should update a product', async () => {
        const productsRes = await request(app)
            .get('/api/products')
            .set('Authorization', `Bearer ${token}`);
        const productId = productsRes.body[0].id;

        const res = await request(app)
            .put(`/api/products/${productId}`)
            .set('Authorization', `Bearer ${token}`)
            .send({
                name: 'Updated Product',
                description: 'Updated product description',
                price: 150,
                stock: 20,
                categoryId: categoryId,
            });
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('name', 'Updated Product');
    });

    it('should delete a product', async () => {
        const productsRes = await request(app)
            .get('/api/products')
            .set('Authorization', `Bearer ${token}`);
        const productId = productsRes.body[0].id;

        const res = await request(app)
            .delete(`/api/products/${productId}`)
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('message', 'Product deleted successfully');
    });
});
