const request = require('supertest');
const app = require('../app');
const prisma = require('../config/db');

let token;

beforeAll(async () => {
    await prisma.user.deleteMany();

    const res = await request(app)
        .post('/api/auth/register')
        .send({
            name: 'Admin User',
            email: 'admin@example.com',
            password: 'admin123',
            role: 'Admin',
        });

    token = res.body.token;
});

afterAll(async () => {
    await prisma.$disconnect();
});

describe('User Endpoints', () => {
    it('should get all users', async () => {
        const res = await request(app)
            .get('/api/users')
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toBeInstanceOf(Array);
    });

    it('should get a single user by ID', async () => {
        const usersRes = await request(app)
            .get('/api/users')
            .set('Authorization', `Bearer ${token}`);
        const userId = usersRes.body[0].id;

        const res = await request(app)
            .get(`/api/users/${userId}`)
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('id');
    });

    it('should update a user', async () => {
        const usersRes = await request(app)
            .get('/api/users')
            .set('Authorization', `Bearer ${token}`);
        const userId = usersRes.body[0].id;

        const res = await request(app)
            .put(`/api/users/${userId}`)
            .set('Authorization', `Bearer ${token}`)
            .send({
                name: 'Updated User',
                email: 'updated@example.com',
            });
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('name', 'Updated User');
        expect(res.body).toHaveProperty('email', 'updated@example.com');
    });

    it('should delete a user', async () => {
        const usersRes = await request(app)
            .get('/api/users')
            .set('Authorization', `Bearer ${token}`);
        const userId = usersRes.body[0].id;

        const res = await request(app)
            .delete(`/api/users/${userId}`)
            .set('Authorization', `Bearer ${token}`);
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('message', 'User deleted successfully');
    });
});
