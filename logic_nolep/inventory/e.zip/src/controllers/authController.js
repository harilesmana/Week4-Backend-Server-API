const Joi = require('joi');
const { objectId } = require('./custom.validation');

const createOrderItem = {
    body: Joi.object().keys({
        quantity: Joi.number().integer().positive().required(),
        price: Joi.number().positive().required(),
        productId: Joi.string().custom(objectId).required(),
        orderId: Joi.string().custom(objectId).required(),
    }),
};

const getOrderItem = {
    params: Joi.object().keys({
        orderItemId: Joi.string().custom(objectId).required(),
    }),
};

const updateOrderItem = {
    params: Joi.object().keys({
        orderItemId: Joi.string().custom(objectId).required(),
    }),
    body: Joi.object()
        .keys({
            quantity: Joi.number().integer().positive(),
            price: Joi.number().positive(),
            productId: Joi.string().custom(objectId),
            orderId: Joi.string().custom(objectId),
        })
        .min(1),
};

const deleteOrderItem = {
    params: Joi.object().keys({
        orderItemId: Joi.string().custom(objectId).required(),
    }),
};

module.exports = { createOrderItem, getOrderItem, updateOrderItem, deleteOrderItem };
