const prisma = require('../config/db');

const createOrder = async (req, res) => {
    const { total, userId, orderItems } = req.body;

    const order = await prisma.order.create({
        data: {
            total,
            userId: parseInt(userId),
            orderItems: {
                create: orderItems.map(item => ({
                    quantity: item.quantity,
                    price: item.price,
                    productId: parseInt(item.productId),
                })),
            },
        },
    });

    
    for (let item of orderItems) {
        await prisma.product.update({
            where: { id: parseInt(item.productId) },
            data: { stock: { decrement: item.quantity } },
        });
    }

    res.json(order);
};

const getAllOrders = async (req, res) => {
    const { page = 1, size = 10 } = req.query;
    const skip = (page - 1) * size;
    const take = parseInt(size);

    const orders = await prisma.order.findMany({
        skip,
        take,
    });

    res.json(orders);
};

const getOrderById = async (req, res) => {
    const { orderId } = req.params;
    const order = await prisma.order.findUnique({ where: { id: parseInt(orderId) } });
    res.json(order);
};

const updateOrder = async (req, res) => {
    const { orderId } = req.params;
    const { total, userId } = req.body;
    const order = await prisma.order.update({
        where: { id: parseInt(orderId) },
        data: { total, userId: parseInt(userId) },
    });
    res.json(order);
};

const deleteOrder = async (req, res) => {
    const { orderId } = req.params;
    await prisma.order.delete({ where: { id: parseInt(orderId) } });
    res.json({ message: 'Order deleted successfully' });
};

module.exports = { createOrder, getAllOrders, getOrderById, updateOrder, deleteOrder };
