const express = require('express');
const { getAllUsers, getUserById, updateUser, deleteUser } = require('../controllers/userController');
const authenticateToken = require('../middlewares/auth');

const router = express.Router();

router.get('/', authenticateToken, getAllUsers);
router.get('/:userId', authenticateToken, getUserById);
router.put('/:userId', authenticateToken, updateUser);
router.delete('/:userId', authenticateToken, deleteUser);

module.exports = router;
