const Joi = require('joi');
const { objectId } = require('./custom.validation');

const createOrder = {
    body: Joi.object().keys({
        total: Joi.number().positive().required(),
        userId: Joi.string().custom(objectId).required(),
        orderItems: Joi.array().items(Joi.object({
            quantity: Joi.number().integer().positive().required(),
            price: Joi.number().positive().required(),
            productId: Joi.string().custom(objectId).required(),
        })).required(),
    }),
};

const getOrder = {
    params: Joi.object().keys({
        orderId: Joi.string().custom(objectId).required(),
    }),
};

const updateOrder = {
    params: Joi.object().keys({
        orderId: Joi.string().custom(objectId).required(),
    }),
    body: Joi.object()
        .keys({
            total: Joi.number().positive(),
            userId: Joi.string().custom(objectId),
            orderItems: Joi.array().items(Joi.object({
                quantity: Joi.number().integer().positive(),
                price: Joi.number().positive(),
                productId: Joi.string().custom(objectId),
            })),
        })
        .min(1),
};

const deleteOrder = {
    params: Joi.object().keys({
        orderId: Joi.string().custom(objectId).required(),
    }),
};

module.exports = { createOrder, getOrder, updateOrder, deleteOrder };
